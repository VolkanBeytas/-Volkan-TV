package com.volkantv.tuner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.media.tv.TvView;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String READ_TV_LISTINGS = "android.permission.READ_TV_LISTINGS";
    private static final int PERMISSION_REQUEST = 1001;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<ChannelItem> allChannels = new ArrayList<>();
    private final ArrayList<ChannelItem> channels = new ArrayList<>();

    private FrameLayout root;
    private TvView tvView;
    private LinearLayout channelPanel;
    private ListView channelList;
    private LinearLayout infoBar;
    private TextView channelTitle;
    private TextView programTitle;
    private TextView programTime;
    private TextView numberBox;
    private TextView statusBox;
    private TextView panelSummary;
    private EditText searchBox;
    private TextView favoritesButton;

    private ChannelAdapter adapter;
    private SharedPreferences prefs;
    private AudioManager audioManager;

    private int currentIndex = -1;
    private int highlightedIndex = 0;
    private long currentChannelId = -1L;
    private String numberBuffer = "";
    private boolean favoritesOnly = false;
    private boolean editDialogOpen = false;

    private static final String PREF_FAVORITES = "favorites";
    private static final String PREF_HIDDEN = "hidden";
    private static final String PREF_ORDER = "custom_order";

    private static class ChannelItem {
        long id;
        String number;
        String name;
        String inputId;
        String videoFormat;

        ChannelItem(long id, String number, String name, String inputId, String videoFormat) {
            this.id = id;
            this.number = number == null ? "" : number;
            this.name = TextUtils.isEmpty(name) ? "İsimsiz Kanal" : name;
            this.inputId = inputId == null ? "" : inputId;
            this.videoFormat = videoFormat == null ? "" : videoFormat;
        }
    }

    private final Runnable numberCommit = () -> {
        if (!numberBuffer.isEmpty()) tuneByNumber(numberBuffer);
        numberBuffer = "";
        numberBox.setVisibility(View.GONE);
    };

    private final Runnable hideInfo = () -> infoBar.setVisibility(View.GONE);

    private final Runnable refreshProgram = new Runnable() {
        @Override public void run() {
            ChannelItem current = findById(currentChannelId);
            if (current != null) updateProgram(current);
            handler.postDelayed(this, 60000);
        }
    };

    private final AudioManager.OnAudioFocusChangeListener audioFocusListener = focus -> {
        if (focus == AudioManager.AUDIOFOCUS_GAIN) {
            try { tvView.setStreamVolume(1.0f); } catch (Exception ignored) {}
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("volkan_tv_v2", MODE_PRIVATE);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUi();
        buildInterface();
        setupTvCallbacks();
        enableTvAudio();

        showStatus("VOLKAN TV v2\nTV sistemi hazırlanıyor…", 3000);

        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(READ_TV_LISTINGS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{READ_TV_LISTINGS}, PERMISSION_REQUEST);
        } else {
            loadTvSystem();
        }
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    private GradientDrawable roundedBg(int color, int strokeColor) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        if (strokeColor != Color.TRANSPARENT) bg.setStroke(dp(1), strokeColor);
        bg.setCornerRadius(dp(12));
        return bg;
    }

    private void buildInterface() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);

        tvView = new TvView(this);
        try { tvView.setStreamVolume(1.0f); } catch (Exception ignored) {}
        root.addView(tvView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        createChannelPanel();
        createInfoBar();
        createNumberBox();
        createStatusBox();

        setContentView(root);
        root.requestFocus();
    }

    private void createChannelPanel() {
        channelPanel = new LinearLayout(this);
        channelPanel.setOrientation(LinearLayout.VERTICAL);
        channelPanel.setPadding(dp(28), dp(24), dp(22), dp(24));

        GradientDrawable panelBg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.argb(248, 8, 10, 16), Color.argb(232, 20, 25, 34)});
        panelBg.setCornerRadii(new float[]{0,0,dp(24),dp(24),dp(24),dp(24),0,0});
        channelPanel.setBackground(panelBg);

        TextView brand = new TextView(this);
        brand.setText("VOLKAN TV");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(28);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setPadding(dp(12), dp(2), dp(12), dp(2));

        TextView subtitle = new TextView(this);
        subtitle.setText("UYDU KANALLARI • v2");
        subtitle.setTextColor(Color.rgb(245, 158, 11));
        subtitle.setTextSize(13);
        subtitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        subtitle.setPadding(dp(12), dp(2), dp(12), dp(8));

        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setHint("Kanal ara…");
        searchBox.setTextColor(Color.WHITE);
        searchBox.setHintTextColor(Color.rgb(150, 158, 172));
        searchBox.setTextSize(16);
        searchBox.setInputType(InputType.TYPE_CLASS_TEXT);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_DONE);
        searchBox.setPadding(dp(16), dp(10), dp(16), dp(10));
        searchBox.setBackground(roundedBg(
                Color.argb(210, 30, 35, 45), Color.rgb(70, 78, 92)));

        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        searchParams.setMargins(dp(8), dp(3), dp(8), dp(8));
        searchBox.setLayoutParams(searchParams);

        searchBox.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) handler.postDelayed(this::showKeyboard, 150);
        });

        searchBox.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                hideKeyboard();
                focusChannelList();
                return true;
            }
            return false;
        });

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilter();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        favoritesButton = new TextView(this);
        favoritesButton.setTextColor(Color.WHITE);
        favoritesButton.setTextSize(15);
        favoritesButton.setGravity(Gravity.CENTER_VERTICAL);
        favoritesButton.setPadding(dp(16), dp(10), dp(16), dp(10));
        favoritesButton.setFocusable(true);
        favoritesButton.setClickable(true);
        favoritesButton.setBackground(roundedBg(
                Color.argb(190, 25, 30, 40), Color.TRANSPARENT));
        favoritesButton.setOnClickListener(v -> toggleFavorites());
        updateFavoritesButton();

        panelSummary = new TextView(this);
        panelSummary.setText("Kanal listesi hazırlanıyor…");
        panelSummary.setTextColor(Color.rgb(175, 182, 194));
        panelSummary.setTextSize(13);
        panelSummary.setPadding(dp(12), dp(8), dp(12), dp(10));

        channelPanel.addView(brand);
        channelPanel.addView(subtitle);
        channelPanel.addView(searchBox);
        channelPanel.addView(favoritesButton);
        channelPanel.addView(panelSummary);

        channelList = new ListView(this);
        channelList.setDivider(null);
        channelList.setDividerHeight(0);
        channelList.setSelector(android.R.color.transparent);
        channelList.setFocusable(true);
        channelList.setFocusableInTouchMode(true);

        adapter = new ChannelAdapter();
        channelList.setAdapter(adapter);

        channelList.setOnItemClickListener((parent, view, position, id) -> {
            highlightedIndex = position;
            tuneChannel(position);
            hideChannelPanel();
        });

        channelList.setOnItemLongClickListener((parent, view, position, id) -> {
            highlightedIndex = position;
            showEditMenu(position);
            return true;
        });

        channelPanel.addView(channelList, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                dp(590), ViewGroup.LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.START;
        root.addView(channelPanel, params);
        channelPanel.setVisibility(View.GONE);
    }

    private void createInfoBar() {
        infoBar = new LinearLayout(this);
        infoBar.setOrientation(LinearLayout.VERTICAL);
        infoBar.setPadding(dp(30), dp(18), dp(30), dp(18));

        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.argb(215, 24, 28, 38), Color.argb(246, 6, 8, 12)});
        bg.setCornerRadius(dp(20));
        infoBar.setBackground(bg);

        channelTitle = new TextView(this);
        channelTitle.setTextColor(Color.WHITE);
        channelTitle.setTextSize(27);
        channelTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);

        programTitle = new TextView(this);
        programTitle.setTextColor(Color.rgb(229, 232, 238));
        programTitle.setTextSize(19);
        programTitle.setPadding(0, dp(5), 0, 0);

        programTime = new TextView(this);
        programTime.setTextColor(Color.rgb(245, 158, 11));
        programTime.setTextSize(15);
        programTime.setPadding(0, dp(5), 0, 0);

        infoBar.addView(channelTitle);
        infoBar.addView(programTitle);
        infoBar.addView(programTime);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.BOTTOM;
        params.setMargins(dp(32), dp(24), dp(32), dp(28));
        root.addView(infoBar, params);
        infoBar.setVisibility(View.GONE);
    }

    private void createNumberBox() {
        numberBox = new TextView(this);
        numberBox.setTextColor(Color.WHITE);
        numberBox.setTextSize(48);
        numberBox.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        numberBox.setGravity(Gravity.CENTER);
        numberBox.setPadding(dp(28), dp(14), dp(28), dp(14));
        numberBox.setBackground(roundedBg(
                Color.argb(238, 13, 16, 23), Color.rgb(245, 158, 11)));

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(220), dp(105));
        params.gravity = Gravity.TOP | Gravity.END;
        params.setMargins(0, dp(42), dp(42), 0);
        root.addView(numberBox, params);
        numberBox.setVisibility(View.GONE);
    }

    private void createStatusBox() {
        statusBox = new TextView(this);
        statusBox.setTextColor(Color.WHITE);
        statusBox.setTextSize(15);
        statusBox.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        statusBox.setPadding(dp(20), dp(14), dp(20), dp(14));
        statusBox.setBackground(roundedBg(
                Color.argb(232, 11, 14, 21), Color.TRANSPARENT));

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                dp(650), ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.setMargins(0, dp(40), dp(40), 0);
        root.addView(statusBox, params);
        statusBox.setVisibility(View.GONE);
    }

    private void enableTvAudio() {
        try {
            if (audioManager != null) {
                audioManager.requestAudioFocus(
                        audioFocusListener,
                        AudioManager.STREAM_MUSIC,
                        AudioManager.AUDIOFOCUS_GAIN);
            }
            if (tvView != null) tvView.setStreamVolume(1.0f);
        } catch (Exception ignored) {}
    }

    private void setupTvCallbacks() {
        tvView.setCallback(new TvView.TvInputCallback() {
            @Override public void onVideoAvailable(String inputId) {
                enableTvAudio();
                handler.postDelayed(MainActivity.this::enableTvAudio, 400);
                showStatus("✓ Uydu görüntüsü alındı", 2200);
            }

            @Override public void onVideoUnavailable(String inputId, int reason) {
                showStatus("Yayın bekleniyor…\nKod: " + reason, 4000);
            }

            @Override public void onConnectionFailed(String inputId) {
                showStatus("TV girişine bağlantı başarısız.", 7000);
            }

            @Override public void onDisconnected(String inputId) {
                showStatus("TV girişi bağlantısı kesildi.", 5000);
            }
        });
    }

    private void loadTvSystem() {
        allChannels.clear();
        channels.clear();

        Set<String> tunerInputIds = new HashSet<>();
        try {
            TvInputManager inputManager =
                    (TvInputManager) getSystemService(TV_INPUT_SERVICE);
            if (inputManager != null) {
                for (TvInputInfo info : inputManager.getTvInputList()) {
                    if (info.getType() == TvInputInfo.TYPE_TUNER) {
                        tunerInputIds.add(info.getId());
                    }
                }
            }
        } catch (Exception ignored) {}

        try {
            String[] projection = {
                    TvContract.Channels._ID,
                    TvContract.Channels.COLUMN_DISPLAY_NUMBER,
                    TvContract.Channels.COLUMN_DISPLAY_NAME,
                    TvContract.Channels.COLUMN_INPUT_ID,
                    TvContract.Channels.COLUMN_VIDEO_FORMAT,
                    TvContract.Channels.COLUMN_BROWSABLE,
                    TvContract.Channels.COLUMN_SERVICE_TYPE
            };

            Cursor cursor = getContentResolver().query(
                    TvContract.Channels.CONTENT_URI,
                    projection,
                    null,
                    null,
                    null);

            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(TvContract.Channels._ID);
                int numCol = cursor.getColumnIndexOrThrow(TvContract.Channels.COLUMN_DISPLAY_NUMBER);
                int nameCol = cursor.getColumnIndexOrThrow(TvContract.Channels.COLUMN_DISPLAY_NAME);
                int inputCol = cursor.getColumnIndexOrThrow(TvContract.Channels.COLUMN_INPUT_ID);
                int formatCol = cursor.getColumnIndexOrThrow(TvContract.Channels.COLUMN_VIDEO_FORMAT);
                int browseCol = cursor.getColumnIndexOrThrow(TvContract.Channels.COLUMN_BROWSABLE);
                int serviceCol = cursor.getColumnIndexOrThrow(TvContract.Channels.COLUMN_SERVICE_TYPE);

                while (cursor.moveToNext()) {
                    long id = cursor.getLong(idCol);
                    String number = cursor.getString(numCol);
                    String name = cursor.getString(nameCol);
                    String inputId = cursor.getString(inputCol);
                    String videoFormat = cursor.getString(formatCol);
                    boolean browsable = cursor.getInt(browseCol) != 0;
                    String serviceType = cursor.getString(serviceCol);

                    if (!browsable) continue;
                    if (!TextUtils.isEmpty(serviceType) &&
                            !TvContract.Channels.SERVICE_TYPE_AUDIO_VIDEO.equals(serviceType)) {
                        continue;
                    }
                    if (TextUtils.isEmpty(name) && TextUtils.isEmpty(number)) continue;
                    if (!tunerInputIds.isEmpty() && !tunerInputIds.contains(inputId)) continue;

                    String upperName = name == null ? "" : name.toUpperCase(Locale.ROOT);
                    if (upperName.contains("VIDEO_FORMAT_") ||
                            upperName.contains("PLAY FINDER")) {
                        continue;
                    }

                    allChannels.add(new ChannelItem(
                            id, number, name, inputId, videoFormat));
                }

                cursor.close();
            }
        } catch (SecurityException e) {
            showStatus("Kanal listesi izni engellendi.", 9000);
        } catch (Exception e) {
            showStatus("Kanal veritabanı okunamadı:\n" +
                    e.getClass().getSimpleName(), 9000);
        }

        Collections.sort(allChannels, new Comparator<ChannelItem>() {
            @Override public int compare(ChannelItem a, ChannelItem b) {
                int na = numberKey(a.number);
                int nb = numberKey(b.number);
                if (na != nb) return Integer.compare(na, nb);
                return a.number.compareToIgnoreCase(b.number);
            }
        });

        applySavedOrder();
        applyFilter();

        if (!channels.isEmpty()) {
            highlightedIndex = 0;
            showStatus("✓ Volkan TV v2 hazır\n" +
                    channels.size() + " TV kanalı bulundu", 4500);
            tuneChannel(0);
        } else {
            showStatus("TV kanal listesi bulunamadı.", 9000);
            showChannelPanel();
        }

        handler.removeCallbacks(refreshProgram);
        handler.postDelayed(refreshProgram, 60000);
    }

    private void applySavedOrder() {
        String saved = prefs.getString(PREF_ORDER, "");
        if (TextUtils.isEmpty(saved)) return;

        Map<Long, ChannelItem> byId = new HashMap<>();
        for (ChannelItem channel : allChannels) {
            byId.put(channel.id, channel);
        }

        ArrayList<ChannelItem> ordered = new ArrayList<>();
        for (String part : saved.split(",")) {
            try {
                ChannelItem channel = byId.remove(Long.parseLong(part));
                if (channel != null) ordered.add(channel);
            } catch (Exception ignored) {}
        }

        for (ChannelItem channel : allChannels) {
            if (byId.containsKey(channel.id)) {
                ordered.add(channel);
                byId.remove(channel.id);
            }
        }

        allChannels.clear();
        allChannels.addAll(ordered);
    }

    private void saveOrder() {
        StringBuilder sb = new StringBuilder();
        for (ChannelItem channel : allChannels) {
            if (sb.length() > 0) sb.append(',');
            sb.append(channel.id);
        }
        prefs.edit().putString(PREF_ORDER, sb.toString()).apply();
    }

    private int numberKey(String number) {
        if (number == null) return 999999;
        String digits = number.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) return 999999;
        try { return Integer.parseInt(digits); }
        catch (Exception e) { return 999999; }
    }

    private Set<String> stringSet(String key) {
        return new HashSet<>(prefs.getStringSet(key, Collections.emptySet()));
    }

    private boolean isFavorite(long id) {
        return stringSet(PREF_FAVORITES).contains(String.valueOf(id));
    }

    private String displayName(ChannelItem channel) {
        String alias = prefs.getString("alias_" + channel.id, "");
        return TextUtils.isEmpty(alias) ? channel.name : alias;
    }

    private void applyFilter() {
        if (adapter == null) return;

        String query = searchBox == null ? "" :
                searchBox.getText().toString().trim()
                        .toLowerCase(new Locale("tr", "TR"));

        Set<String> hidden = stringSet(PREF_HIDDEN);
        Set<String> favorites = stringSet(PREF_FAVORITES);

        channels.clear();

        for (ChannelItem channel : allChannels) {
            String id = String.valueOf(channel.id);

            if (hidden.contains(id)) continue;
            if (favoritesOnly && !favorites.contains(id)) continue;

            if (!query.isEmpty()) {
                String haystack =
                        (channel.number + " " +
                         displayName(channel) + " " +
                         channel.name)
                                .toLowerCase(new Locale("tr", "TR"));

                if (!haystack.contains(query)) continue;
            }

            channels.add(channel);
        }

        if (highlightedIndex >= channels.size()) {
            highlightedIndex = Math.max(0, channels.size() - 1);
        }

        adapter.notifyDataSetChanged();
        updatePanelSummary();
    }

    private void updatePanelSummary() {
        if (panelSummary == null) return;

        String text = channels.size() + " kanal";
        if (favoritesOnly) text += " • favoriler";
        if (searchBox != null && searchBox.length() > 0) text += " • arama";
        text += " • INFO: ara • MENU: düzenle";

        panelSummary.setText(text);
    }

    private void updateFavoritesButton() {
        if (favoritesButton == null) return;

        favoritesButton.setText(
                favoritesOnly
                        ? "★ FAVORİLER — OK: TÜM KANALLAR"
                        : "☆ TÜM KANALLAR — OK: FAVORİLER");
    }

    private void toggleFavorites() {
        favoritesOnly = !favoritesOnly;
        updateFavoritesButton();
        applyFilter();
        focusChannelList();
    }

    private void tuneChannel(int index) {
        if (channels.isEmpty()) return;
        if (index < 0) index = channels.size() - 1;
        if (index >= channels.size()) index = 0;

        currentIndex = index;
        highlightedIndex = index;

        ChannelItem channel = channels.get(index);
        currentChannelId = channel.id;

        Uri channelUri = ContentUris.withAppendedId(
                TvContract.Channels.CONTENT_URI, channel.id);

        try {
            enableTvAudio();
            tvView.setStreamVolume(1.0f);
            tvView.tune(channel.inputId, channelUri);

            handler.postDelayed(this::enableTvAudio, 300);
            handler.postDelayed(this::enableTvAudio, 1000);

            showChannelInfo(channel);
        } catch (SecurityException e) {
            showStatus("Tuner erişimi Android tarafından engellendi.", 9000);
        } catch (Exception e) {
            showStatus("Kanal açılamadı:\n" +
                    e.getClass().getSimpleName() + "\n" +
                    e.getMessage(), 9000);
        }

        adapter.notifyDataSetChanged();
    }

    private ChannelItem findById(long id) {
        for (ChannelItem channel : allChannels) {
            if (channel.id == id) return channel;
        }
        return null;
    }

    private int visibleIndex(long id) {
        for (int i = 0; i < channels.size(); i++) {
            if (channels.get(i).id == id) return i;
        }
        return -1;
    }

    private void showChannelInfo(ChannelItem channel) {
        String number =
                channel.number.isEmpty() ? "" : channel.number + "   ";
        String star = isFavorite(channel.id) ? "★ " : "";

        channelTitle.setText(star + number + displayName(channel));
        programTitle.setText("Program bilgisi aranıyor…");
        programTime.setText(
                channel.videoFormat.isEmpty()
                        ? "Uydu yayını"
                        : "Kaynak: " + channel.videoFormat);

        infoBar.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideInfo);
        handler.postDelayed(hideInfo, 5500);

        updateProgram(channel);
    }

    private void updateProgram(ChannelItem channel) {
        long now = System.currentTimeMillis();

        try {
            Uri uri = TvContract.buildProgramsUriForChannel(
                    channel.id,
                    now - 60000,
                    now + 6L * 60L * 60L * 1000L);

            String[] projection = {
                    TvContract.Programs.COLUMN_TITLE,
                    TvContract.Programs.COLUMN_START_TIME_UTC_MILLIS,
                    TvContract.Programs.COLUMN_END_TIME_UTC_MILLIS
            };

            Cursor cursor = getContentResolver().query(
                    uri, projection, null, null, null);

            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String title = cursor.getString(0);
                    long start = cursor.getLong(1);
                    long end = cursor.getLong(2);

                    if (start <= now && end > now) {
                        programTitle.setText(
                                TextUtils.isEmpty(title)
                                        ? "Program bilgisi yok"
                                        : title);

                        DateFormat df = DateFormat.getTimeInstance(
                                DateFormat.SHORT,
                                new Locale("tr", "TR"));

                        programTime.setText(
                                df.format(new Date(start)) +
                                " – " +
                                df.format(new Date(end)));

                        cursor.close();
                        return;
                    }
                }

                cursor.close();
            }

            programTitle.setText("Program bilgisi yok");
        } catch (Exception e) {
            programTitle.setText("EPG bilgisi kullanılamıyor");
        }
    }

    private void tuneByNumber(String number) {
        for (int i = 0; i < channels.size(); i++) {
            if (channels.get(i).number.equals(number)) {
                tuneChannel(i);
                return;
            }
        }

        try {
            int wanted = Integer.parseInt(number);

            for (int i = 0; i < channels.size(); i++) {
                String clean =
                        channels.get(i).number.replaceAll("[^0-9]", "");

                if (!clean.isEmpty() &&
                        Integer.parseInt(clean) == wanted) {
                    tuneChannel(i);
                    return;
                }
            }
        } catch (Exception ignored) {}

        showStatus("Kanal " + number + " bulunamadı.", 2500);
    }

    private void showChannelPanel() {
        channelPanel.setVisibility(View.VISIBLE);

        int index = visibleIndex(currentChannelId);

        if (index >= 0) highlightedIndex = index;
        else highlightedIndex =
                Math.min(highlightedIndex,
                        Math.max(0, channels.size() - 1));

        focusChannelList();
    }

    private void focusChannelList() {
        if (channels.isEmpty()) {
            favoritesButton.requestFocus();
            return;
        }

        channelList.setSelection(highlightedIndex);
        channelList.requestFocus();
        adapter.notifyDataSetChanged();
    }

    private void hideChannelPanel() {
        hideKeyboard();
        channelPanel.setVisibility(View.GONE);
        root.requestFocus();
    }

    private void showKeyboard() {
        if (searchBox == null) return;

        searchBox.requestFocus();
        searchBox.setSelection(searchBox.length());

        InputMethodManager imm =
                (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);

        if (imm != null) {
            imm.showSoftInput(
                    searchBox,
                    InputMethodManager.SHOW_IMPLICIT);
        }
    }

    private void hideKeyboard() {
        if (searchBox == null) return;

        InputMethodManager imm =
                (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);

        if (imm != null) {
            imm.hideSoftInputFromWindow(
                    searchBox.getWindowToken(), 0);
        }
    }

    private void moveHighlight(int direction) {
        if (channels.isEmpty()) return;

        highlightedIndex += direction;

        if (highlightedIndex < 0) {
            highlightedIndex = 0;
            favoritesButton.requestFocus();
            return;
        }

        if (highlightedIndex >= channels.size()) {
            highlightedIndex = channels.size() - 1;
        }

        channelList.setSelection(highlightedIndex);
        adapter.notifyDataSetChanged();
    }

    private void zap(int direction) {
        if (channels.isEmpty()) return;

        int index = visibleIndex(currentChannelId);

        if (index < 0) index = 0;
        else index += direction;

        if (index < 0) index = channels.size() - 1;
        if (index >= channels.size()) index = 0;

        tuneChannel(index);
    }

    private void handleNumber(int number) {
        if (numberBuffer.length() >= 4) numberBuffer = "";

        numberBuffer += number;
        numberBox.setText(numberBuffer);
        numberBox.setVisibility(View.VISIBLE);

        handler.removeCallbacks(numberCommit);
        handler.postDelayed(numberCommit, 1400);
    }

    private void showEditMenu(int position) {
        if (position < 0 ||
                position >= channels.size() ||
                editDialogOpen) return;

        ChannelItem channel = channels.get(position);
        boolean favorite = isFavorite(channel.id);

        editDialogOpen = true;

        String[] items = {
                favorite
                        ? "★ Favorilerden çıkar"
                        : "☆ Favoriye ekle",
                "Kanal adını değiştir",
                "Yukarı taşı",
                "Aşağı taşı",
                "Bu kanalı gizle",
                "Özel adı sıfırla",
                "Gizlenen tüm kanalları geri getir"
        };

        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle(
                                (channel.number.isEmpty()
                                        ? ""
                                        : channel.number + " • ") +
                                displayName(channel))
                        .setItems(items, (d, which) -> {
                            editDialogOpen = false;

                            switch (which) {
                                case 0:
                                    toggleFavorite(channel);
                                    break;
                                case 1:
                                    renameChannel(channel);
                                    break;
                                case 2:
                                    moveChannel(channel, -1);
                                    break;
                                case 3:
                                    moveChannel(channel, 1);
                                    break;
                                case 4:
                                    hideChannel(channel);
                                    break;
                                case 5:
                                    prefs.edit()
                                            .remove("alias_" + channel.id)
                                            .apply();
                                    applyFilter();
                                    break;
                                case 6:
                                    prefs.edit()
                                            .remove(PREF_HIDDEN)
                                            .apply();
                                    applyFilter();
                                    break;
                            }
                        })
                        .setOnCancelListener(d -> editDialogOpen = false)
                        .create();

        dialog.show();
    }

    private void toggleFavorite(ChannelItem channel) {
        Set<String> set = stringSet(PREF_FAVORITES);
        String id = String.valueOf(channel.id);

        if (set.contains(id)) set.remove(id);
        else set.add(id);

        prefs.edit()
                .putStringSet(PREF_FAVORITES, set)
                .apply();

        applyFilter();
    }

    private void hideChannel(ChannelItem channel) {
        Set<String> set = stringSet(PREF_HIDDEN);
        set.add(String.valueOf(channel.id));

        prefs.edit()
                .putStringSet(PREF_HIDDEN, set)
                .apply();

        applyFilter();
        focusChannelList();
    }

    private void renameChannel(ChannelItem channel) {
        editDialogOpen = true;

        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(displayName(channel));
        input.setSelectAllOnFocus(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);

        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle("Kanal adını değiştir")
                        .setView(input)
                        .setPositiveButton("Kaydet", (d, w) -> {
                            editDialogOpen = false;

                            String value =
                                    input.getText()
                                            .toString()
                                            .trim();

                            if (value.isEmpty()) {
                                prefs.edit()
                                        .remove("alias_" + channel.id)
                                        .apply();
                            } else {
                                prefs.edit()
                                        .putString(
                                                "alias_" + channel.id,
                                                value)
                                        .apply();
                            }

                            applyFilter();
                        })
                        .setNegativeButton(
                                "İptal",
                                (d, w) -> editDialogOpen = false)
                        .setOnCancelListener(
                                d -> editDialogOpen = false)
                        .create();

        dialog.setOnShowListener(d -> {
            input.requestFocus();

            handler.postDelayed(() -> {
                InputMethodManager imm =
                        (InputMethodManager)
                                getSystemService(
                                        Context.INPUT_METHOD_SERVICE);

                if (imm != null) {
                    imm.showSoftInput(
                            input,
                            InputMethodManager.SHOW_IMPLICIT);
                }
            }, 200);
        });

        dialog.show();
    }

    private void moveChannel(ChannelItem channel, int direction) {
        int index = -1;

        for (int i = 0; i < allChannels.size(); i++) {
            if (allChannels.get(i).id == channel.id) {
                index = i;
                break;
            }
        }

        if (index < 0) return;

        int target = index + direction;

        if (target < 0 ||
                target >= allChannels.size()) return;

        Collections.swap(allChannels, index, target);
        saveOrder();
        applyFilter();

        highlightedIndex =
                Math.max(0, visibleIndex(channel.id));

        focusChannelList();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (editDialogOpen) {
            return super.dispatchKeyEvent(event);
        }

        if (event.getAction() != KeyEvent.ACTION_DOWN) {
            return super.dispatchKeyEvent(event);
        }

        int key = event.getKeyCode();

        if (channelPanel.getVisibility() == View.VISIBLE &&
                searchBox.hasFocus()) {

            if (key == KeyEvent.KEYCODE_DPAD_DOWN) {
                hideKeyboard();
                focusChannelList();
                return true;
            }

            if (key == KeyEvent.KEYCODE_BACK) {
                hideKeyboard();
                focusChannelList();
                return true;
            }

            return super.dispatchKeyEvent(event);
        }

        if (key >= KeyEvent.KEYCODE_0 &&
                key <= KeyEvent.KEYCODE_9 &&
                channelPanel.getVisibility() != View.VISIBLE) {

            handleNumber(key - KeyEvent.KEYCODE_0);
            return true;
        }

        switch (key) {
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                if (channelPanel.getVisibility() == View.VISIBLE) {
                    if (favoritesButton.hasFocus()) {
                        toggleFavorites();
                    } else if (!channels.isEmpty()) {
                        tuneChannel(highlightedIndex);
                        hideChannelPanel();
                    }
                } else {
                    showChannelPanel();
                }
                return true;

            case KeyEvent.KEYCODE_DPAD_UP:
                if (channelPanel.getVisibility() == View.VISIBLE) {
                    if (favoritesButton.hasFocus()) {
                        searchBox.requestFocus();
                        showKeyboard();
                    } else {
                        moveHighlight(-1);
                    }
                } else {
                    zap(1);
                }
                return true;

            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (channelPanel.getVisibility() == View.VISIBLE) {
                    if (favoritesButton.hasFocus()) {
                        focusChannelList();
                    } else {
                        moveHighlight(1);
                    }
                } else {
                    zap(-1);
                }
                return true;

            case KeyEvent.KEYCODE_CHANNEL_UP:
                zap(1);
                return true;

            case KeyEvent.KEYCODE_CHANNEL_DOWN:
                zap(-1);
                return true;

            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (channelPanel.getVisibility() != View.VISIBLE) {
                    zap(1);
                    return true;
                }
                break;

            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (channelPanel.getVisibility() != View.VISIBLE) {
                    zap(-1);
                    return true;
                }
                break;

            case KeyEvent.KEYCODE_INFO:
            case KeyEvent.KEYCODE_SEARCH:
                if (channelPanel.getVisibility() != View.VISIBLE) {
                    showChannelPanel();
                }
                searchBox.requestFocus();
                showKeyboard();
                return true;

            case KeyEvent.KEYCODE_MENU:
                if (channelPanel.getVisibility() == View.VISIBLE &&
                        !channels.isEmpty() &&
                        channelList.hasFocus()) {
                    showEditMenu(highlightedIndex);
                } else {
                    showChannelPanel();
                }
                return true;

            case KeyEvent.KEYCODE_GUIDE:
                showChannelPanel();
                return true;

            case KeyEvent.KEYCODE_BACK:
                if (channelPanel.getVisibility() == View.VISIBLE) {
                    hideChannelPanel();
                    return true;
                }
                break;
        }

        return super.dispatchKeyEvent(event);
    }

    private void showStatus(String text, long duration) {
        statusBox.setText(text);
        statusBox.setVisibility(View.VISIBLE);

        handler.postDelayed(
                () -> statusBox.setVisibility(View.GONE),
                duration);
    }

    private int dp(int value) {
        return (int)
                (value *
                 getResources()
                         .getDisplayMetrics()
                         .density + 0.5f);
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults);

        if (requestCode == PERMISSION_REQUEST) {
            if (grantResults.length > 0 &&
                    grantResults[0] ==
                            PackageManager.PERMISSION_GRANTED) {
                showStatus(
                        "✓ TV kanal listesi izni verildi.",
                        2000);
            } else {
                showStatus(
                        "TV kanal listesi izni verilmedi.",
                        5000);
            }

            loadTvSystem();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUi();
        enableTvAudio();
    }

    @Override
    protected void onPause() {
        hideKeyboard();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);

        try {
            if (audioManager != null) {
                audioManager.abandonAudioFocus(audioFocusListener);
            }
        } catch (Exception ignored) {}

        try { tvView.reset(); } catch (Exception ignored) {}

        super.onDestroy();
    }

    private class ChannelAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return channels.size();
        }

        @Override
        public Object getItem(int position) {
            return channels.get(position);
        }

        @Override
        public long getItemId(int position) {
            return channels.get(position).id;
        }

        @Override
        public View getView(
                int position,
                View convertView,
                ViewGroup parent) {

            TextView row;

            if (convertView instanceof TextView) {
                row = (TextView) convertView;
            } else {
                row = new TextView(MainActivity.this);
                row.setTextSize(20);
                row.setTextColor(Color.WHITE);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(
                        dp(18),
                        dp(15),
                        dp(16),
                        dp(15));
            }

            ChannelItem channel = channels.get(position);

            String star =
                    isFavorite(channel.id)
                            ? "★  "
                            : "";

            String label =
                    star +
                    (channel.number.isEmpty()
                            ? "—"
                            : channel.number) +
                    "     " +
                    displayName(channel);

            row.setText(label);

            GradientDrawable bg =
                    new GradientDrawable();

            if (position == highlightedIndex &&
                    channelList.hasFocus()) {
                bg.setColor(
                        Color.argb(
                                115,
                                245,
                                158,
                                11));

                row.setTypeface(
                        Typeface.DEFAULT,
                        Typeface.BOLD);
            } else {
                bg.setColor(Color.TRANSPARENT);

                row.setTypeface(
                        Typeface.DEFAULT,
                        Typeface.NORMAL);
            }

            bg.setCornerRadius(dp(12));
            row.setBackground(bg);

            return row;
        }
    }
}
